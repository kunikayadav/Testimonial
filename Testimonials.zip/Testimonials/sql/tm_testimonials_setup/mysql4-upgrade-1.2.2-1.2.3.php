<?php
 
$installer = $this;
$connection = $installer->getConnection();
 
$installer->startSetup();
 
$installer->getConnection()
    ->addColumn($installer->getTable('tm_testimonials/data'),
    'company 2',
    array(
        'type' => Varien_Db_Ddl_Table::TYPE_VARCHAR, 255,array(),
        'nullable' => true,
        'default' => null,
        'comment' => 'company 2'
    )
);
 
$installer->endSetup();