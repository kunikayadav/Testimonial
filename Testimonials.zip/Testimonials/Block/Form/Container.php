<?php
class TM_Testimonials_Block_Form_Container extends Mage_Core_Block_Template
{

}