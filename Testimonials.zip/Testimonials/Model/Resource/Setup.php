<?php
class TM_Testimonials_Model_Resource_Setup extends Mage_Core_Model_Resource_Setup {

}